# Français au lycée – Maroc V8 — Android

Version V8 prête pour la construction Android avec Capacitor 7.

## Build GitHub Actions
Le workflow `.github/workflows/build-apk.yml` :
1. installe Node.js 20 et Java 17 ;
2. prépare le dossier `www` ;
3. génère le vrai dossier `android/` avec Capacitor ;
4. synchronise Capacitor ;
5. construit l'APK debug ;
6. publie l'APK dans un Artifact ;
7. publie également le projet Android complet dans un second Artifact.

### Depuis un téléphone
Après avoir envoyé le projet sur GitHub :
- ouvre **Actions** ;
- sélectionne **Build Android APK** ;
- lance **Run workflow** ;
- à la fin, télécharge `Francais-au-lycee-Maroc-V8-debug-apk` pour l'APK ;
- télécharge `Francais-au-lycee-Maroc-V8-android-project` pour le dossier Android complet.

## Build local
1. `npm install`
2. `./prepare-web.sh`
3. `npx cap add android`
4. `npx cap sync android`
5. `cd android && ./gradlew assembleDebug`

Identifiant Android : `ma.francaislycee.app`.
