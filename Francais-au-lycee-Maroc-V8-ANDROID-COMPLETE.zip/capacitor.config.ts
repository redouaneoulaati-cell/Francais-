import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ma.francaislycee.app',
  appName: 'Français au lycée – Maroc',
  // Capacitor doit copier une vraie racine web, pas ".".
  webDir: 'www',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https'
  }
};

export default config;
