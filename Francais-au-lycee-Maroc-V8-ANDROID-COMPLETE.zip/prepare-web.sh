#!/usr/bin/env bash
set -euo pipefail

rm -rf www
mkdir -p www

cp index.html styles.css app.js config.js sw.js manifest.webmanifest www/
cp -R icons www/
cp -R books www/

echo "Web files prepared in ./www"
find www -maxdepth 2 -type f | sort
