import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' }

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  try {
    const { question } = await req.json()
    if (!question?.trim()) return new Response(JSON.stringify({ error: 'Question vide' }), { status: 400, headers: { ...cors, 'Content-Type': 'application/json' } })

    const apiKey = Deno.env.get('OPENAI_API_KEY')
    if (!apiKey) return new Response(JSON.stringify({ answer: 'Le moteur IA est prêt, mais la clé OPENAI_API_KEY doit être configurée dans les secrets Supabase.' }), { headers: { ...cors, 'Content-Type': 'application/json' } })

    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({ model: Deno.env.get('OPENAI_MODEL') || 'gpt-5.6-mini', input: `Tu es un assistant pédagogique spécialisé en français au lycée au Maroc. Réponds en français, de façon claire, structurée et adaptée à un élève. N'invente pas le contenu d'un programme officiel. Question : ${question}` })
    })
    const data = await r.json()
    const answer = data.output_text || data.output?.flatMap((x:any)=>x.content||[]).find((x:any)=>x.type==='output_text')?.text || 'Je n’ai pas pu générer une réponse.'
    return new Response(JSON.stringify({ answer }), { headers: { ...cors, 'Content-Type': 'application/json' } })
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: { ...cors, 'Content-Type': 'application/json' } })
  }
})
