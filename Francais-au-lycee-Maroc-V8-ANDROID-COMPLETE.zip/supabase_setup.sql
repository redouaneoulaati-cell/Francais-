-- Extensions V5 : exercices, livres PDF, discussions et temps réel
create table if not exists public.exercises (
 id uuid primary key default gen_random_uuid(),
 question text not null,
 answer text,
 level text not null,
 created_at timestamptz not null default now()
);
create table if not exists public.books (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text,
 level text,
 file_url text not null,
 is_published boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.discussion_messages (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete set null,
 author_name text,
 content text,
 audio_url text,
 created_at timestamptz not null default now()
);
insert into public.exercises (question,answer,level) values
('Choisis le bon connecteur : « Il a travaillé, ___ il a réussi. »','donc','Tronc commun'),
('Identifie la figure : « La lune est un miroir. »','métaphore','Tronc commun'),
('Quel est le but principal d’un texte argumentatif ?','défendre une thèse','1er Bac'),
('Dans une dissertation, que formule-t-on avant le plan ?','une problématique','2e Bac'),
('Le narrateur qui sait tout est…','omniscient','2e Bac'),
('« Comme un lion » est une…','comparaison','1er Bac');

-- Active le temps réel pour les messages si la publication n’existe pas déjà.
alter publication supabase_realtime add table public.discussion_messages;

-- Bucket pour les messages vocaux. À défaut de création SQL selon la version du projet,
-- crée-le dans Storage avec le nom : voice-messages, puis active les policies adaptées.
insert into storage.buckets (id,name,public) values ('voice-messages','voice-messages',true) on conflict (id) do nothing;

-- Classes virtuelles et vidéos pédagogiques
create table if not exists public.live_meetings (
 id uuid primary key default gen_random_uuid(),
 teacher_id uuid references auth.users(id) on delete set null,
 title text not null,
 level text,
 starts_at timestamptz not null,
 room_name text not null unique,
 is_published boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.lesson_videos (
 id uuid primary key default gen_random_uuid(),
 teacher_id uuid references auth.users(id) on delete set null,
 title text not null,
 description text,
 level text,
 url text not null,
 is_published boolean not null default true,
 created_at timestamptz not null default now()
);
alter table public.live_meetings enable row level security;
alter table public.lesson_videos enable row level security;
drop policy if exists "published meetings readable" on public.live_meetings;
create policy "published meetings readable" on public.live_meetings for select using (is_published = true or auth.uid() = teacher_id);
drop policy if exists "teachers create meetings" on public.live_meetings;
create policy "teachers create meetings" on public.live_meetings for insert with check (auth.uid() = teacher_id);
drop policy if exists "published videos readable" on public.lesson_videos;
create policy "published videos readable" on public.lesson_videos for select using (is_published = true or auth.uid() = teacher_id);
drop policy if exists "teachers create videos" on public.lesson_videos;
create policy "teachers create videos" on public.lesson_videos for insert with check (auth.uid() = teacher_id);
